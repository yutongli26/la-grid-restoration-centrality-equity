# Redo Sufficiency Gate Addendum

This redo package incorporates a final targeted correction pass before zipping. The package remains WIST-only: no ratios, no WIST weights, no normalized weights, no crew numbers, no D01-D16 list change, no coordinate change, and no substation-candidate change.

Corrections incorporated before package closure:

- D11 Montebello: upgraded from C/no-source to Category B based on California DIR/DOSH facility-specific pressure-vessel registration evidence for SCE CRE - Montebello Service Center at 1000 Potrero Grande Dr with an outside garage-shed location.
- D10 Santa Monica: upgraded to A-caveated / manual review because DIR/DOSH rows link the same 1721 22nd St address to SCE CRE Santa Monica Garage and SCE Colorado Substation 66-kV equipment. This is address-level station-equipment relevance, not proof of observed HV/substation repair crews.
- D12 Whittier/Santa Fe Springs, D13 South Bay, D16 Long Beach, D08 Pomona, D07 Dominguez Hills, and D14 Covina/San Dimas retain only the public-evidence boundary stated in the tables; all crew-base, crew-count, roster, dispatch, and measured-capacity claims remain prohibited unless a source explicitly proves them.

Final decision after redo: B. Some rows have stronger evidence and should have updated evidence-boundary categories, but no WIST score or weight change should be implemented without user authorization.

# WIST D01-D16 Supplemental Public-Evidence Memo

## 1. Purpose and scope

This redo is a supplemental public-evidence pass for the fixed Stage 4/5 WIST D01-D16 origin-proxy evidence package. The scope is WIST-only. It evaluates whether public sources support each fixed origin as a direct HV/substation/T&D/station-support proxy, an indirect logistics/operations proxy, a generic service-center/work-location proxy, or an office/control/admin-only proxy.

## 2. Explicit non-actions

No ratios, WIST scores, normalized weights, crew numbers, depot-list changes, coordinate changes, or substation-candidate changes were performed. No category update has been implemented in the model. This memo only recommends evidence-boundary updates.

## 3. Source hierarchy used

The strongest sources used were official LADWP facility pages, SCE/CPUC GRC testimony, CEQA public-agency records, public-agency DIR/DOSH equipment-location records, and SCE job-posting evidence tied to a facility/function. Weak sources and search-result snippets were not used to prove crew count, measured capacity, or direct HV/substation function.

## 4. Summary by utility

For LADWP, D01 and D06 remain the strongest A rows. D01 is directly identified as a Substations Regional Center with visible yard/tool-room/loading-dock/repair-bay support. D06 is directly linked by LADWP imagery to repair/fabrication, warehouse/loading-dock, power-system components, receiving station, and distribution station. D02 and D03 remain B-level or B-caveated because they show logistics/support elements but do not prove current facility-level HV/substation repair operations. D04 is weak after this pass and should be treated as C unless stronger Valley Center logistics/electric-operations evidence is found. D05 remains B-caveated because warehouse/service-center evidence is useful but still needs exact source capture before manuscript-grade citation.

For SCE, D09 and D14 are the only A-caveated rows. D09 is supported by SCE GRC testimony tying Alhambra logistics/warehouse distribution to Substation Construction Maintenance and Transmission assets. D14 is supported by an SCE transmission job posting tying Metro East Transmission / Covina Service Center to transmission field-crew supervision and emergency restoration, but not to observed crew capacity. D07, D08, D10, D12, D13, D15, and D16 are B-level logistics rows if the exact DIR/DOSH query records are archived. D11 remains C because no Montebello-specific garage/warehouse/materials/T&D source was confirmed.

## 5. Rows upgraded to Category A

None newly upgraded to uncaveated A. D09 and D14 are confirmed as A-caveated, not observed field crew bases.

## 6. Rows upgraded to Category B

D12 and D16 should be upgraded from C to B, subject to the noted naming/source-capture caveats. D12 has facility-specific garage evidence for the Santa Fe Springs/Whittier SCE location. D16 has facility-specific wash-bay and hazmat-storage evidence.

## 7. Rows remaining Category C

D11 remains C. D04 should be considered C unless the user authorizes retaining B based on weaker contextual evidence or a stronger source is later found.

## 8. Rows remaining manual-review

D02, D03, D04, D05, D09, D12, and D14 should remain manual-review rows for different reasons: mixed admin/logistics evidence, historical station ambiguity, weak source support, source-capture need, material/logistics-versus-crew-base boundary, naming reconciliation, or job-posting-versus-capacity boundary.

## 9. Rows with only generic service-center / work-location / site-scale evidence

D11 is the clearest generic-only row. D04 is also weak/generic based on the public source found in this redo.

## 10. Rows publicly proven as observed HV/substation repair crew bases

None. Public sources support origin-proxy relevance, facility identity, operations/logistics support, material support, or transmission-function association. They do not prove observed HV/substation repair crew bases.

## 11. Rows with observed crew count / roster / dispatch / measured capacity evidence

None.

## 12. Whether any WIST score or weight change is required now

No. Evidence-boundary changes alone do not authorize WIST score or weight changes. D12 and D16 can be recommended for category-boundary upgrade to B, and D04 can be flagged as a downgrade candidate, but no WIST parameter change should be implemented without explicit user authorization.

## 13. Recommended paper-safe language

The Stage 4/5 WIST layer is a public-evidence-informed ordinal origin-proxy allocation layer. Public evidence supports facility identity, broad function, and relative logistics or station-support relevance for several origins, but does not provide observed facility-level HV/substation repair crew counts, yard-level rosters, disaster dispatch assignments, or measured repair capacity. Scenario-level effective crew-equivalent totals are allocated across fixed origins using evidence-bounded proxy weights, not observed rosters.

## 14. Prohibited language

Do not write that any D01-D16 facility has a verified crew count, observed disaster dispatch capacity, measured repair capacity, validated utility workforce share, or empirically observed yard-level staffing allocation. Do not describe D09 or D14 as observed crew bases. Do not upgrade D03 to direct A solely from Station 11 imagery. Do not borrow garage evidence from one SCE service center to classify another.

## Final decision

B. Some rows have stronger evidence and should have updated evidence-boundary categories, but no WIST score or weight change should be implemented without user authorization. D12 and D16 are evidence-supported B upgrades. D04 is a downgrade/manual-review candidate. D09 and D14 remain A-caveated, not observed crew-base evidence.
