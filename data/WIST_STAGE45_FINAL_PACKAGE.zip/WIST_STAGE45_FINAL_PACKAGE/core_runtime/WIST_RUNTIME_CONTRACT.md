# WIST Final Runtime Contract

Required input table: `WIST_RUNTIME_INPUT_MINIMAL.csv` for model/runtime use, or `WIST_CANONICAL_WEIGHT_TABLE.csv` when metadata and caveats are needed.

Required invariants:

- Required row count = 16.
- Required depot_id set = D01-D16 exactly.
- Denominator includes all active D01-D16 rows.
- D02, D09, and D12 remain included and caveated.
- All normalized weights must be positive.
- Normalized weight sum tolerance: 1.0 ± 1e-5. Current exported sum = 1.000001000.
- Runtime code must not renormalize after dropping manual-review rows.
- Runtime code must not infer total crew number from WIST.

Allocation formula:

`origin_allocation_i = externally_specified_total_effective_crew_equivalent × normalized_wist_weight_i`

WIST does not estimate the externally specified total. It only distributes a separately specified scenario-level effective crew-equivalent total across fixed repair-origin proxies.
