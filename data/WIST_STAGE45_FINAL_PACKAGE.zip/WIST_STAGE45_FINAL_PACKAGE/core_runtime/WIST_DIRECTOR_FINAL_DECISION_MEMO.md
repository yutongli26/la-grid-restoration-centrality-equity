# WIST director final decision memo

## Final decision

**Final decision: pass_with_caveats; no score change required.**

The current WIST table is numerically reproducible and can be used as a paper-facing ordinal origin-proxy allocation layer, but only under explicit claim boundaries. The prior decision label, `pass_without_change`, is superseded as wording because it is too strong for a package that still contains weak-proxy cells and manual-review rows. The numerical decision is unchanged: no component score or normalized weight requires revision at this time.

## Why the wording changed

The earlier label could be misread as saying that every WIST number is directly measured or directly evidenced. That is not the correct interpretation. The evidence ledger distinguishes direct public evidence, rubric-binned public evidence, and weak public-evidence proxies. Some scores are direct evidence, some are rubric-binned from public evidence, and some are weak public-evidence proxies. No current retained score is classified as inadmissible, but the presence of weak-proxy cells means the table must be reported as a caveated ordinal allocation layer rather than as an empirical capacity calibration.

## Why no numeric score change is required

The admissibility audit found no retained component score outside the repaired admissible rubric band. The current table contains no retained score classified as inadmissible and no component score that must be lowered before use. The raw WIST scores are formula-derived from the accepted component scores and methodological coefficients. The normalized WIST weights are denominator-derived across all fixed D01-D16 rows. These numbers are therefore reproducible as source-constrained ordinal allocation weights, not measured depot capacities.

The retained evidence-category counts are: direct public evidence = 23 records; rule-based from public evidence = 72 records; weak proxy from public evidence = 33 records; researcher-assigned judgment = 0 records; inadmissible = 0 records. These counts support conditional use with caveats, not unrestricted claims of measured capacity.

## Manual-review rows

D02, D09, and D12 remain manual-review rows with positive weights. The manual-review flag constrains interpretation and paper wording. It does not delete the row, set the weight to zero, remove the row from the denominator, or convert the row to a metadata-only record.

D02 may remain a positive operations-support origin proxy, but it may not be described as direct high-voltage repair crew evidence. D09 may be described only as a caveated substation-material, T&D, or regional-operations proxy; it must not be described as observed field crew capacity. D12 remains low-positive and weak-proxy only.

## Generic SCE service-center caveat

Generic SCE service-center rows may support facility identity, service-center role, public site-scale binning, local operations proxy use, and geographic coverage. They may not be described as proven high-voltage repair crew bases. Generic service-center identity does not establish substation crew capacity, station-equipment repair capability, yard-level roster, or observed dispatch behavior.

D08 is retained as a logistics or garage/CRE-type proxy where supported, but this is not observed repair crew capacity.

## Geographic and utility-aggregate caveats

Geographic coverage is only a spatial-distribution proxy. It is not evidence of crew capacity, utility responsibility, staffing, or dispatch share.

Utility aggregate WIST weights are post hoc row-label summaries only. They are not LADWP/SCE staffing shares, service responsibility shares, restoration responsibility shares, or dispatch shares. Any aggregate difference reflects the retained fixed origin-proxy rows and their ordinal scores, not measured utility crew availability.

## Final paper-safe paragraph

WIST is a public-evidence-informed ordinal origin-proxy allocation layer used to distribute an externally specified scenario-level effective crew-equivalent total across fixed D01-D16 repair-origin proxies. Component scores represent source-constrained ordinal judgments for facility identity, high-voltage/substation relevance, operations support, site scale or service-center evidence, marginal geographic coverage, and evidence confidence. The resulting normalized weights are not observed staffing counts, yard-level rosters, measured repair capacity, utility workforce shares, restoration responsibility shares, or dispatch shares. D02, D09, and D12 remain positive but caveated manual-review rows; generic SCE service centers remain capped as service-center proxy rows unless direct high-voltage, substation, station-equipment, or T&D-function evidence is present.

The WIST table is accepted for Stage 4/5 only as a caveated ordinal origin-proxy allocation layer. It is not accepted as empirical evidence of depot-level repair capacity or crew availability.
