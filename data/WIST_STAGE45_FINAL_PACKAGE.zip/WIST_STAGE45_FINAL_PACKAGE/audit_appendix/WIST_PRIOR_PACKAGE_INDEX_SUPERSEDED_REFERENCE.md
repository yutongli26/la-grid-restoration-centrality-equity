# WIST final package index

## Final accepted files

The final accepted WIST package consists of the following files:

1. `WIST_DIRECTOR_FINAL_DECISION_MEMO.md` — final director-adjudicated decision: pass_with_caveats; no score change required.
2. `WIST_FINAL_PAPER_METHODS_PARAGRAPH.md` — clean paper methods paragraph and interpretation boundary.
3. `WIST_FINAL_RUNTIME_CONTRACT.md` — input-table, row-count, denominator, and allocation-formula contract.
4. `WIST_FINAL_CLAIM_BOUNDARY_TABLE.csv` — allowed and forbidden WIST claims with replacement wording.
5. `wist_origin_proxy_weight_table_CONDITIONAL_LOCK.csv` — current inclusive D01-D16 Table A with unchanged conditional-lock weights.
6. `wist_source_to_component_score_admissibility_audit_CONDITIONAL_LOCK.csv` — component admissibility audit showing no D or E retained classifications.
7. `wist_cell_by_cell_numeric_defensibility_ledger.csv` — cell-by-cell numeric defensibility ledger.
8. `wist_component_weight_theory_justification.md` — methodological defense of component coefficients.
9. `wist_equal_weight_sensitivity_check.csv` — equal-component-weight diagnostic sensitivity table.
10. `wist_final_numeric_closure_memo.md` — numeric closure memo distinguishing source-traceable ordinal scores from directly evidenced numerical values.
11. `wist_targeted_evidence_closure_table.csv` and `wist_targeted_evidence_closure_memo.md` — targeted evidence closure for high-risk rows.
12. `WIST_ALLOWED_AND_FORBIDDEN_CLAIMS.md` — claim-boundary reference.

## Superseded files or wording

Earlier WIST files that used `pass_without_change` as the final decision label are superseded for final paper-facing decision language. The superseding decision language is `pass_with_caveats; no score change required`.

Earlier files suggesting a fully locked, final, or unrestricted paper-ready WIST baseline without caveats are superseded. The current accepted status is conditional/caveated use as a source-constrained ordinal origin-proxy allocation layer.

Older files or tables that excluded D02, D09, or D12 from the denominator, treated manual-review flags as exclusion flags, or used an included-yard denominator instead of all D01-D16 origins are superseded.

Older WIST drafts that implied source-constrained ordinal proxy capacity claims that were too strong, observed crew count, yard roster, utility staffing share, restoration responsibility share, or dispatch share are superseded by the final claim-boundary files.

## Implementation boundary

The accepted implementation input is the inclusive D01-D16 conditional-lock table. The package does not patch repository code and does not modify the damaged-substation candidate set, origin list, coordinates, utility labels, yard status, or scenario-level total crew number.
