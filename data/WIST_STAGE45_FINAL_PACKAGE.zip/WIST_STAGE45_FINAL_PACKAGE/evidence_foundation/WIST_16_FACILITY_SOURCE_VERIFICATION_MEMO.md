# WIST 16-Facility Public Evidence Source-Verification Memo

## Purpose

This memo documents facility-level public evidence for the fixed Stage 4/5 WIST D01-D16 origin-proxy list. It is an evidence-collection and evidence-boundary document only. No WIST weights, ratios, normalized weights, crew numbers, crew rosters, or observed dispatch/capacity estimates were calculated.

## Source search method

The correction pass used public source re-verification rather than treating the WIST package as evidence. The search and extraction prioritized: official LADWP facility pages, CPUC-hosted SCE General Rate Case workpapers, California DIR/Cal-OSHA public registration records, official SCE job postings, and public partner-profile records where stronger official records were not available. Each row was assigned an evidence-boundary category based on what the public source directly proves, not on inferred utility ownership, yard size, geography, or nonzero WIST weight.

## Source hierarchy used

Tier 1 sources used here include official LADWP pages, CPUC-hosted regulatory workpapers, and California DIR public agency records. Tier 2 sources include official SCE job postings and Los Angeles Better Buildings Challenge partner-profile pages. No map, satellite-only, or geocoder-only evidence was used to prove operations, high-voltage relevance, crew-base status, or capacity.

## Facility-by-facility evidence summary

### D01 — LADWP Substations Regional Center

Primary evidence boundary: Category A. Strongest source: Palmetto Facility (Parking Lot).

Paper-safe interpretation: Official evidence supports use as a LADWP Substations Regional Center origin proxy with yard, warehouse, repair-bay, and vehicle-support features.

Limit: Even with direct substation-support labels, no public source verifies observed crew count, roster, dispatch assignment, or measured repair capacity.

### D02 — LADWP Central District HQ / Central District Facility

Primary evidence boundary: Category B. Strongest source: Central District Facility (Wall St.).

Paper-safe interpretation: Official evidence supports a mixed LADWP central facility logistics/work-location proxy with service yard, warehouse/crafts buildings, service bays, and administrative buildings.

Limit: Central District can be described as a logistics/work-location proxy, not as a proven high-voltage/substation repair crew base.

### D03 — LADWP Boylston Facility

Primary evidence boundary: Category B. Strongest source: Boylston Facility (Civic Center Underground).

Paper-safe interpretation: Official evidence supports Boylston as a logistics/control/work-location proxy because the source shows garage, warehouse loading dock, office/garage, and Station 11 elements.

Limit: Boylston has facility-function evidence beyond office/control, but public evidence does not verify high-voltage/substation repair crews or capacity.

### D04 — LADWP Valley Center

Primary evidence boundary: Category B. Strongest source: LADWP — Partner Profiles Blog / Valley Center entries.

Paper-safe interpretation: Public partner-profile evidence supports Valley Center as a LADWP work-location/logistics proxy with admin, repair-services, and warehouse labels.

Limit: Valley Center evidence supports logistics/work-location functions only; HV/substation repair crew-base status is not verified.

### D05 — LADWP Central Service Center

Primary evidence boundary: Category B. Strongest source: Central Service Center - Admin & WH.

Paper-safe interpretation: Public evidence supports Central Service Center as an Admin & WH work-location/logistics proxy with site-scale information.

Limit: Central Service Center is usable as a caveated origin proxy, not as a verified HV/substation crew base.

### D06 — LADWP Main Street Facility

Primary evidence boundary: Category A. Strongest source: Main Street Facility.

Paper-safe interpretation: Official evidence supports a direct station/power-system support proxy because the site includes central repair/fabrication, warehouse/loading dock, power-system components, receiving station, and distribution station labels.

Limit: Direct station-support relevance exists, but crew count, dispatch role, and measured repair capacity are not public evidence.

### D07 — SCE Dominguez Hills Service Center

Primary evidence boundary: Category B. Strongest source: California DIR Pressure Vessel Registration database - SCE CRE - Dominguez Hills Service Center entries.

Paper-safe interpretation: Public evidence supports Dominguez Hills as an SCE service-center/logistics proxy with garage oil room and outside prefab evidence; GRC source supplies service-center scale.

Limit: Dominguez Hills has operations-support evidence, but no public proof of HV/substation repair crew-base status or capacity.

### D08 — SCE Pomona Service Center / SCE CRE Pomona Garage

Primary evidence boundary: Category B. Strongest source: California DIR Pressure Vessel Registration database - SCE CRE Pomona Garage entries.

Paper-safe interpretation: Public evidence supports Pomona as a transportation/garage/logistics proxy with compressor/dyno/training-building garage evidence and GRC transportation-services scale.

Limit: Pomona supports logistics/garage interpretation only unless further station-equipment evidence is identified.

### D09 — SCE Alhambra Combined Facility / Alhambra Regional Operations Facility

Primary evidence boundary: Category A. Strongest source: Energy Management Systems Developer, Associate Specialist in Alhambra, CA, US.

Paper-safe interpretation: Public evidence supports Alhambra as a regional operations/control and T&D/substation work-process support proxy; GRC confirms the regional operations facility and scale.

Limit: Alhambra has direct T&D/substation support relevance, but this is not evidence of observed crews, rosters, dispatch assignments, or capacity.

### D10 — SCE Santa Monica Service Center

Primary evidence boundary: Category B. Strongest source: California DIR Pressure Vessel Registration database - SCE CRE Santa Monica Garage entry.

Paper-safe interpretation: Public evidence supports Santa Monica as an SCE service-center/logistics proxy with garage tire/store-room evidence; GRC source supplies service-center scale.

Limit: Santa Monica has garage/store-room operations-support evidence, not station-equipment repair crew-base evidence.

### D11 — SCE Montebello Service Center

Primary evidence boundary: Category C. Strongest source: SCE-06 Vol. 7 Workpapers Book A: SCE Facility List Managed by Facility Operations.

Paper-safe interpretation: Public evidence supports Montebello as a generic SCE service-center/work-location proxy with site-scale data.

Limit: Montebello evidence is limited to service-center identity and site scale.

### D12 — SCE Whittier Service Center / Santa Fe Springs location

Primary evidence boundary: Category C. Strongest source: SCE-06 Vol. 7 Workpapers Book A: SCE Facility List Managed by Facility Operations.

Paper-safe interpretation: Public evidence supports Whittier as a generic SCE service-center/work-location proxy with site-scale data.

Limit: Whittier evidence is limited to service-center identity and site scale.

### D13 — SCE South Bay Service Center

Primary evidence boundary: Category B. Strongest source: California DIR Pressure Vessel Registration database - SCE CRE South Bay Garage entries.

Paper-safe interpretation: Public evidence supports South Bay as an SCE service-center/logistics proxy with garage, tire-area, and prefab evidence; GRC source supplies service-center scale.

Limit: South Bay has garage/prefab operations-support evidence, not station-equipment repair crew-base evidence.

### D14 — SCE Covina / San Dimas Service Center

Primary evidence boundary: Category C. Strongest source: SCE-06 Vol. 7 Workpapers Book A: SCE Facility List Managed by Facility Operations.

Paper-safe interpretation: Public evidence supports Covina/San Dimas as a generic SCE service-center/work-location proxy with site-scale data.

Limit: Covina/San Dimas evidence is limited to service-center identity and site scale.

### D15 — SCE Monrovia Service Center

Primary evidence boundary: Category B. Strongest source: California DIR Pressure Vessel Registration database - SCE CRE Monrovia S/C Garage entry.

Paper-safe interpretation: Public evidence supports Monrovia as an SCE service-center/logistics proxy with garage-adjacent evidence; GRC source supplies service-center scale.

Limit: Monrovia has garage-adjacent operations-support evidence, not station-equipment repair crew-base evidence.

### D16 — SCE Long Beach Service Center

Primary evidence boundary: Category C. Strongest source: SCE-06 Vol. 7 Workpapers Book A: SCE Facility List Managed by Facility Operations.

Paper-safe interpretation: Public evidence supports Long Beach as a generic SCE service-center/work-location proxy with site-scale data.

Limit: Long Beach evidence is limited to service-center identity and site scale.

## Facilities with direct HV / substation / station-equipment support evidence

- D01 — LADWP Substations Regional Center
- D06 — LADWP Main Street Facility
- D09 — SCE Alhambra Combined Facility / Alhambra Regional Operations Facility

These rows have public evidence that directly links the facility to substation, station-equipment, T&D operations/work-process support, receiving/distribution station, or comparable power-system station-support relevance. This still does not prove observed HV/substation repair crew-base status.

## Facilities with indirect logistics / operations support evidence only

- D02 — LADWP Central District HQ / Central District Facility
- D03 — LADWP Boylston Facility
- D04 — LADWP Valley Center
- D05 — LADWP Central Service Center
- D07 — SCE Dominguez Hills Service Center
- D08 — SCE Pomona Service Center / SCE CRE Pomona Garage
- D10 — SCE Santa Monica Service Center
- D13 — SCE South Bay Service Center
- D15 — SCE Monrovia Service Center

These rows have public evidence supporting warehouse, garage, service yard, repair services, fabrication, loading dock, store-room, prefab, transportation, or similar logistics/operations support, but not observed high-voltage/substation repair crew-base status.

## Facilities with generic service-center / work-location evidence only

- D11 — SCE Montebello Service Center
- D12 — SCE Whittier Service Center / Santa Fe Springs location
- D14 — SCE Covina / San Dimas Service Center
- D16 — SCE Long Beach Service Center

These rows are supported by public evidence primarily as service-center/work-location/site-scale records. No stronger facility-specific logistics, garage, T&D, station-equipment, or high-voltage/substation support source was identified in this pass.

## Facilities with office / HQ / control / administrative evidence only

- None

No row was assigned as office/HQ/control/administrative only after this correction pass. D02 and D03 contain office/control elements, but their checked public sources also include service-yard, warehouse, garage, loading-dock, service-bay, or comparable logistics/work-location evidence, so Category D alone would be too narrow.

## Facilities with no public proof of HV/substation repair crew-base status

- D01 — LADWP Substations Regional Center
- D02 — LADWP Central District HQ / Central District Facility
- D03 — LADWP Boylston Facility
- D04 — LADWP Valley Center
- D05 — LADWP Central Service Center
- D06 — LADWP Main Street Facility
- D07 — SCE Dominguez Hills Service Center
- D08 — SCE Pomona Service Center / SCE CRE Pomona Garage
- D09 — SCE Alhambra Combined Facility / Alhambra Regional Operations Facility
- D10 — SCE Santa Monica Service Center
- D11 — SCE Montebello Service Center
- D12 — SCE Whittier Service Center / Santa Fe Springs location
- D13 — SCE South Bay Service Center
- D14 — SCE Covina / San Dimas Service Center
- D15 — SCE Monrovia Service Center
- D16 — SCE Long Beach Service Center

No D01-D16 origin is publicly verified as an observed HV/substation repair crew base. No public source identified in this pass proves facility-level HV/substation repair crew roster, observed dispatch assignment, crew count, or measured repair capacity.

## Interpretation limits

Category A means direct high-voltage/substation/station-equipment or comparable T&D/station-support relevance exists in public evidence. Category A does not mean observed repair crews, crew counts, dispatch assignments, or measured depot-level repair capacity exist.

Category B means the facility has source-verified logistics, operations, garage, warehouse, repair, fabrication, loading-dock, store-room, prefab, transportation, or field-support evidence. Category B supports a caveated origin-proxy role, not a direct HV/substation crew-base claim.

Category C means the evidence supports only generic service-center/work-location/site-scale identity. Such rows may remain in WIST as fixed origin proxies, but the paper should not claim direct HV/substation or logistics function unless a stronger source is added.

## Weight and crew-number boundary

No weights, ratios, normalized scores, crew numbers, crew rosters, or measured capacities were calculated. This memo does not revise WIST weights, origin IDs, facility names, coordinates, substation candidates, or code.

## Main caveat

Facility-level public evidence supports varying degrees of identity, logistics, operations, service-center, and high-voltage/substation support relevance across the fixed D01-D16 origins. However, no facility should be interpreted as having a publicly observed high-voltage/substation repair crew count, yard-level roster, measured dispatch capacity, or empirically verified depot-level repair capacity unless such evidence is explicitly identified.
