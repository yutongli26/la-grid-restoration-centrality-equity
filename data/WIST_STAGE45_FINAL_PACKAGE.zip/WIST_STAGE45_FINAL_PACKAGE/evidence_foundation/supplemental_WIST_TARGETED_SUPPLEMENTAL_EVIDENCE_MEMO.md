# WIST Targeted Supplemental Evidence Memo

## 1. Purpose

This pass searched only for supplemental public evidence for selected weak or borderline D01-D16 WIST origin proxies. It did not calculate ratios, WIST scores, normalized weights, total crew numbers, observed crew counts, yard-level rosters, dispatch shares, or measured repair capacities. The fixed D01-D16 list, yard status, coordinates, damaged-substation candidate set, and existing WIST interpretation were not changed.

## 2. Search scope and source hierarchy

The search targeted public evidence for facility identity, high-voltage / substation / T&D / station-material relevance, repair/logistics support, garage/fleet/warehouse/materials evidence, service-center or work-location support, and site-scale corroboration. Stronger sources were prioritized: official LADWP/SCE pages, CPUC/GRC/CEQA documents, public-agency databases, Energy Safety/CPUC-style records, and official utility documents. Job-posting mirrors and directories were treated as weaker evidence and were not used as proof of crew-base status or measured capacity.

## 3. Summary of new evidence found

The strongest new evidence was for D09. A CPUC/SCE GRC filing describes the Alhambra Regional Operations Facility as a 38.5-acre, 12-building campus with a new warehouse intended as a centralized logistics intake and physical onsite distribution point for Substation Construction Maintenance, Transmission, and IT assets. A separate CPUC environmental document links the Alhambra Combined Facility to handling/disposal logistics for removed 66 kV relay panels and related substation devices. This supports D09 as a caveated direct station-material / T&D / regional-operations proxy, but it still does not prove observed field crew capacity.

D02 and D03 were strengthened by official LADWP facility pages. D02 is documented with Central District service yard, power-system components, warehouse/crafts buildings, and service bays. D03 is documented with Boylston garage/loading-dock features and Station 11 labels. These sources support operations/logistics or station-feature proxy use, not direct high-voltage repair-crew evidence.

For D08, D10, D13, and D15, California DIR/DOSH pressure-vessel records corroborate SCE CRE garage-related facilities and store-room/prefab/tire-area features. These are useful indirect logistics/operations-support sources, but they do not establish high-voltage/substation repair crew-base status.

D11 and D12 remain weak. A secondary job-posting mirror links Montebello and Whittier service centers to an SCE facilities AOR that includes substations and warehouse/garage locations, but the source supports work-location/facilities-compliance context rather than direct field logistics or repair-origin evidence. D14 remains generic service-center/site-work evidence only based on a CIWQS record for Covina Service Center paving. D16 remains generic service-center evidence only based on SCE Electrical Service Requirements service-center listing.

## 4. Facilities upgraded from Category C to B

D02 and D03 are strengthened from weak/manual-review type support toward indirect logistics/operations-support evidence because official LADWP pages document service-yard, warehouse/crafts-building, service-bay, garage/loading-dock, and Station 11/site features. D15 is strengthened to indirect garage/logistics support because a public agency source identifies an SCE CRE Monrovia service-center garage.

## 5. Facilities upgraded to Category A

D09 is confirmed as Category A for direct HV/substation/station-equipment support relevance in the limited WIST sense. The basis is substation-material / transmission-asset logistics and regional operations evidence, not observed repair-crew capacity.

## 6. Facilities still only generic service-center / work-location evidence

D11, D12, D14, and D16 remain generic service-center / work-location / site-scale evidence only. D12 remains manual-review and low-positive/weak-proxy only. D07 did not receive a stronger supplemental source in this pass and should remain caveated under the existing package.

## 7. Facilities lacking public proof of observed HV/substation repair crew-base status

All D01-D16 origins lack public proof of observed high-voltage/substation repair crew-base status, observed yard-level roster, observed dispatch assignment, or measured depot repair capacity. Even the stronger D01, D06, and D09 rows must be described as origin-proxy evidence, not observed crew evidence.

## 8. Whether any evidence requires WIST weight revision

No immediate score or weight revision is required by this targeted evidence pass. The new evidence either supports the existing caveated categories or confirms that weak rows must remain weak-proxy/manual-review rows. No score was found to be clearly outside its admissible rubric band based on the supplemental evidence.

## 9. Whether any evidence requires paper-caveat revision

Yes, paper caveats should remain explicit. Generic SCE service-center rows must not be described as high-voltage/substation repair crew bases. Garage, warehouse, service-yard, and site-scale evidence should be described only as operations/logistics proxy evidence. Geographic and service-center evidence should not be framed as capacity or dispatch evidence.

## 10. No calculation statement

No ratios, WIST weights, normalized weights, total crew numbers, crew counts, crew-equivalent totals, or scenario allocations were calculated in this pass.

## Final targeted conclusion

A. no score change required; caveats retained.

## Required summary

1. New evidence found for D11/D12/D14/D16: D11/D12 have weak secondary job-posting AOR evidence; D14 has public-agency Covina Service Center paving/site-work evidence; D16 has official SCE service-center listing evidence. None proves direct HV/substation repair-origin function.
2. New evidence found for D07/D10/D13/D15: D10/D13/D15 have public-agency DOSH garage/store-room/prefab/tire-area evidence; D07 did not receive a stronger supplemental source in this pass.
3. New evidence found for D09: Strong CPUC/SCE GRC and CPUC environmental evidence supports Alhambra Regional Operations Facility / Combined Facility as substation-material, transmission-asset, warehouse, and regional-operations logistics proxy.
4. New evidence found for D02/D03: Official LADWP pages support Central District service-yard/warehouse/crafts/service-bay/power-system-component features and Boylston garage/loading-dock/Station 11 features.
5. Facilities upgraded to direct HV/substation/station-equipment support evidence: D09 only, in the limited station-material / T&D / regional-operations proxy sense.
6. Facilities upgraded to indirect logistics/operations support evidence: D02, D03, D08, D10, D13, and D15 are strengthened or corroborated as indirect operations/logistics/support proxies.
7. Facilities still generic service-center/work-location only: D11, D12, D14, D16, and D07 absent stronger supplemental evidence in this pass.
8. Facilities publicly proven as observed HV/substation repair crew bases: none.
9. Facilities with observed crew count / roster / dispatch / measured capacity evidence: none.
10. Did you calculate any ratios, WIST weights, normalized weights, or crew numbers? no
11. Did you change the D01-D16 list? no
12. Is any WIST score change required now? no
13. Main caveat for later scoring: supplemental evidence supports varying levels of facility identity, operations/logistics, station-material, and service-center proxy status, but no origin has public evidence of observed crew count, yard-level roster, dispatch share, or measured repair capacity.
