# WIST Source-Verification Audit Memo — Corrected Evidence-Boundary Pass

## Scope

This correction pass only revises the evidence-boundary categories in the source-verification table. It does not revise WIST weights, D01-D16 membership, coordinates, yard status, crew-number scenarios, code, or the damaged-substation candidate set.

The correction applies a stricter distinction between: (1) public evidence that supports direct high-voltage/substation/station-equipment support relevance; (2) public evidence that supports indirect logistics or operations support; and (3) public evidence that supports only generic service-center or work-location identity. No origin is promoted to observed HV/substation repair crew-base status.

## Did the previous evidence-boundary memo rely on source-verified facts or package-inferred summaries?

The prior memo mixed source-verified facts with package-inferred boundary summaries. The correction table resolves this by treating rows as source_verified only where an identified public source title/URL supports the corrected boundary category. After correction, D03, D07, D10, D13, and D15 are no longer left as package-inferred because the identified checked sources support a corrected Category B interpretation.

## Source-verified rows

All D01-D16 rows are source-verified at the corrected evidence-boundary level:

- D01 LADWP Substations Regional Center: Palmetto Facility (Parking Lot) | Los Angeles Department of Water and Power (official LADWP filming-location page). Boundary: Category A — Direct high-voltage / substation / station-equipment repair-support evidence.
- D02 LADWP Central District HQ: Central District Facility (Wall St.) | Los Angeles Department of Water and Power (official LADWP filming-location page). Boundary: Category B — Indirect logistics / operations support, not direct high-voltage crew-base evidence.
- D03 LADWP Boylston Facility: Boylston Facility (Civic Center Underground) | Los Angeles Department of Water and Power (official LADWP filming-location page). Boundary: Category B — Indirect logistics / operations support, not direct high-voltage crew-base evidence.
- D04 LADWP Valley Center: LADWP Properties Portfolio entries on Los Angeles Better Buildings Challenge (LA Better Buildings Challenge partner-profile portfolio page). Boundary: Category B — Indirect logistics / operations support, not direct high-voltage crew-base evidence.
- D05 LADWP Central Service Center: Central Service Center - Admin & WH — Los Angeles Better Buildings Challenge (LA Better Buildings Challenge partner-profile page). Boundary: Category B — Indirect logistics / operations support, not direct high-voltage crew-base evidence.
- D06 LADWP Main Street Facility: Main Street Facility | Los Angeles Department of Water and Power (official LADWP filming-location page). Boundary: Category A — Direct high-voltage / substation / station-equipment repair-support evidence.
- D07 SCE Dominguez Hills Service Center: SCE 2025 GRC Workpaper SCE-06 Vol. 7; California DIR Pressure Vessel Registration results (CPUC public workpaper plus California DIR public registration database). Boundary: Category B — Indirect logistics / operations support, not direct high-voltage crew-base evidence.
- D08 SCE Pomona Service Center / SCE CRE Pomona Garage: CPUC A.23-05-010 TURN-SCE-031 Vehicle Maintenance Facilities data response; California DIR Pressure Vessel Registration results (CPUC public data-response PDF plus California DIR public registration database). Boundary: Category B — Indirect logistics / operations support, not direct high-voltage crew-base evidence.
- D09 SCE Alhambra Combined Facility: Energy Management Systems Developer, Associate Specialist | Southern California Edison; SCE 2025 GRC Workpaper SCE-06 Vol. 7 (SCE careers page plus CPUC public workpaper). Boundary: Category A — Direct high-voltage / substation / station-equipment repair-support evidence.
- D10 SCE Santa Monica Service Center: SCE 2025 GRC Workpaper SCE-06 Vol. 7; California DIR Pressure Vessel Registration results (CPUC public workpaper plus California DIR public registration database). Boundary: Category B — Indirect logistics / operations support, not direct high-voltage crew-base evidence.
- D11 SCE Montebello Service Center: SCE 2025 GRC Workpaper SCE-06 Vol. 7 (CPUC public GRC workpaper). Boundary: Category C — Generic service center / work-location / district facility only.
- D12 SCE Whittier Service Center / Santa Fe Springs location: SCE 2025 GRC Workpaper SCE-06 Vol. 7 (CPUC public GRC workpaper). Boundary: Category C — Generic service center / work-location / district facility only.
- D13 SCE South Bay Service Center: SCE 2025 GRC Workpaper SCE-06 Vol. 7; CPUC A.23-05-010 TURN-SCE-031 Vehicle Maintenance Facilities data response (CPUC public workpaper and data-response PDF). Boundary: Category B — Indirect logistics / operations support, not direct high-voltage crew-base evidence.
- D14 SCE Covina / San Dimas Service Center: SCE 2025 GRC Workpaper SCE-06 Vol. 7 (CPUC public GRC workpaper). Boundary: Category C — Generic service center / work-location / district facility only.
- D15 SCE Monrovia Service Center: SCE 2025 GRC Workpaper SCE-06 Vol. 7; California DIR Pressure Vessel Registration results (CPUC public workpaper plus California DIR public registration database). Boundary: Category B — Indirect logistics / operations support, not direct high-voltage crew-base evidence.
- D16 SCE Long Beach Service Center: SCE 2025 GRC Workpaper SCE-06 Vol. 7 (CPUC public GRC workpaper). Boundary: Category C — Generic service center / work-location / district facility only.

## Package-inferred rows

None after correction. The rows previously marked package_inferred were corrected to the boundary category directly supported by their identified sources.

## Rows requiring boundary-category correction

- D03 LADWP Boylston Facility
  - Correction: Corrected from office/HQ/control-only because the checked LADWP Boylston source identifies garage, warehouse loading dock, and Station 11 elements. This supports a logistics/control/work-location proxy, but not a verified HV/substation repair crew base.
- D07 SCE Dominguez Hills Service Center
  - Correction: Corrected from generic service-center-only because checked CPUC/DIR sources identify Dominguez Hills Service Center plus Garage Oil Room and Outside Pre Fab evidence. This supports indirect logistics/operations support, not HV/substation crew-base status.
- D10 SCE Santa Monica Service Center
  - Correction: Corrected from generic service-center-only because checked CPUC/DIR sources identify Santa Monica Service Center plus Garage Tire/Store Room evidence. This supports indirect logistics/operations support, not HV/substation crew-base status.
- D13 SCE South Bay Service Center
  - Correction: Corrected from generic service-center-only because checked CPUC sources identify South Bay Service Center and South Bay Garage among SCE service facilities where vehicles are serviced. This supports indirect logistics/operations support, not HV/substation crew-base status.
- D15 SCE Monrovia Service Center
  - Correction: Corrected from generic service-center-only because checked CPUC/DIR sources identify Monrovia Service Center plus SCE CRE - Monrovia S/C Garage evidence. This supports indirect logistics/operations support, not HV/substation crew-base status.

## Rows with direct HV/substation support evidence

- D01 LADWP Substations Regional Center
  - Boundary: direct HV/substation/station-equipment support evidence.
  - Caveat: this does not prove observed HV/substation repair crew-base status, observed crew roster, dispatch assignment, or measured repair capacity.
- D06 LADWP Main Street Facility
  - Boundary: direct HV/substation/station-equipment support evidence.
  - Caveat: this does not prove observed HV/substation repair crew-base status, observed crew roster, dispatch assignment, or measured repair capacity.
- D09 SCE Alhambra Combined Facility
  - Boundary: direct HV/substation/station-equipment support evidence.
  - Caveat: this does not prove observed HV/substation repair crew-base status, observed crew roster, dispatch assignment, or measured repair capacity.

## Rows with indirect logistics / operations support evidence

- D02 LADWP Central District HQ
  - Boundary: indirect logistics/operations support proxy only; not direct HV/substation repair crew-base evidence.
- D03 LADWP Boylston Facility
  - Boundary: indirect logistics/operations support proxy only; not direct HV/substation repair crew-base evidence.
- D04 LADWP Valley Center
  - Boundary: indirect logistics/operations support proxy only; not direct HV/substation repair crew-base evidence.
- D05 LADWP Central Service Center
  - Boundary: indirect logistics/operations support proxy only; not direct HV/substation repair crew-base evidence.
- D07 SCE Dominguez Hills Service Center
  - Boundary: indirect logistics/operations support proxy only; not direct HV/substation repair crew-base evidence.
- D08 SCE Pomona Service Center / SCE CRE Pomona Garage
  - Boundary: indirect logistics/operations support proxy only; not direct HV/substation repair crew-base evidence.
- D10 SCE Santa Monica Service Center
  - Boundary: indirect logistics/operations support proxy only; not direct HV/substation repair crew-base evidence.
- D13 SCE South Bay Service Center
  - Boundary: indirect logistics/operations support proxy only; not direct HV/substation repair crew-base evidence.
- D15 SCE Monrovia Service Center
  - Boundary: indirect logistics/operations support proxy only; not direct HV/substation repair crew-base evidence.

## Rows with generic service-center/work-location evidence only

- D11 SCE Montebello Service Center
  - Boundary: generic service-center/work-location evidence only. Existing checked sources do not prove garage, store-room, prefab, vehicle-maintenance, T&D, substation, or station-equipment relevance for this row.
- D12 SCE Whittier Service Center / Santa Fe Springs location
  - Boundary: generic service-center/work-location evidence only. Existing checked sources do not prove garage, store-room, prefab, vehicle-maintenance, T&D, substation, or station-equipment relevance for this row.
- D14 SCE Covina / San Dimas Service Center
  - Boundary: generic service-center/work-location evidence only. Existing checked sources do not prove garage, store-room, prefab, vehicle-maintenance, T&D, substation, or station-equipment relevance for this row.
- D16 SCE Long Beach Service Center
  - Boundary: generic service-center/work-location evidence only. Existing checked sources do not prove garage, store-room, prefab, vehicle-maintenance, T&D, substation, or station-equipment relevance for this row.

## Rows publicly proven as HV/substation repair crew bases

None. D01, D06, and D09 have direct HV/substation/station-equipment support evidence, but this is not the same as public proof of an observed HV/substation repair crew base. No row has public evidence proving observed crew roster, dispatch assignment, actual depot-level repair crew count, or measured repair capacity.

## Are any current classifications unsupported?

After correction, no row is unsupported at the evidence-boundary level. The corrected categories are deliberately narrower than repair-capacity claims. D11, D12, D14, and D16 remain generic service-center/work-location rows because the checked source only supports service-center identity and square footage.

## Does this require WIST weight changes?

No. This is a paper-claim and evidence-boundary correction only. The WIST weights remain unchanged because the correction does not alter D01-D16 membership, coordinates, yard status, or normalized weights.

## Does this require stronger paper caveats?

Yes. The paper should explicitly state that WIST is an ordinal origin-proxy layer and that even rows with direct support evidence do not prove observed depot-level HV/substation repair crew capacity.

## Paper-safe wording

WIST origins are retained as public-evidence-informed ordinal spatial proxies for allocating an externally specified effective-crew scenario. Facility evidence supports varying levels of direct station-equipment support, indirect logistics/operations support, or generic service-center/work-location identity, but does not establish observed yard-level crews, rosters, dispatch assignments, or measured repair capacity.

## Prohibited wording

Do not describe any D01-D16 origin as a verified HV/substation repair crew base, measured repair-capacity depot, observed crew roster location, facility-level workforce share, or observed dispatch origin. Do not infer crew counts from WIST weights, yard size, service-center labels, garage labels, office/control functions, or facility ownership.

## Required summary

- Source-verified rows: D01, D02, D03, D04, D05, D06, D07, D08, D09, D10, D11, D12, D13, D14, D15, D16
- Package-inferred rows: None
- Rows requiring boundary-category correction: D03, D07, D10, D13, D15
- Rows with direct HV/substation support evidence: D01, D06, D09
- Rows with indirect logistics / operations support evidence: D02, D03, D04, D05, D07, D08, D10, D13, D15
- Rows with generic service-center/work-location evidence only: D11, D12, D14, D16
- Rows publicly proven as HV/substation repair crew bases: None
- Whether WIST weights must change: no
- Whether stronger paper caveats are required: yes

No D01-D16 origin is publicly verified as an observed HV/substation repair crew base. WIST remains usable only as a caveated ordinal origin-proxy allocation layer, not as depot-level repair capacity evidence.
