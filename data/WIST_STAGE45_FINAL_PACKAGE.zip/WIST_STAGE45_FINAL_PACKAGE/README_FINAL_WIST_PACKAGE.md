# WIST Stage 4/5 Final Package

Final status: **accepted with caveats; no WIST score or weight change required**.

This package is WIST-only. It provides the final public-evidence-informed ordinal origin-proxy allocation layer for fixed D01–D16 repair origins. It does not estimate total crew number and does not validate any C29/C36/C72-type scenario.

## Core runtime rule

`origin_allocation_i = externally_specified_total_effective_crew_equivalent × normalized_wist_weight_i`

The externally specified total must be supplied from outside WIST. WIST only distributes that total across fixed D01–D16 origins.

## Final evidence tiers

- Category A — direct HV/substation/station-equipment support relevance: D01, D06, D09.
- Category B — indirect logistics / operations support evidence: D02, D03, D04, D05, D07, D08, D10, D13, D15.
- Category C — generic service-center / work-location / site-scale evidence only: D11, D12, D14, D16.

No D01–D16 facility is publicly verified as an observed HV/substation repair crew base. No facility-level public crew roster, dispatch assignment, or measured repair capacity is identified.

## Numeric QA

- Canonical row count: 16.
- Normalized WIST weight sum: 1.000001. The 0.000001 deviation from 1.000000 is six-decimal rounding.
- Manual-review rows retained: D02, D09, D12.
- Active denominator: all D01–D16 rows.

## Folder map

### `core_runtime/`
Use these for downstream analysis and paper-facing methods:

- `WIST_CANONICAL_WEIGHT_TABLE.csv`: full canonical table with names, coordinates, raw scores, normalized weights, ranks, flags, and caveats.
- `WIST_RUNTIME_INPUT_MINIMAL.csv`: minimal model input table.
- `WIST_RUNTIME_CONTRACT.md`: strict runtime rules and prohibited uses.
- `WIST_FINAL_METHODS_PARAGRAPH.md`: paper-ready methods paragraph.
- `WIST_CLAIM_BOUNDARY_TABLE.csv`: allowed/prohibited claim table.
- `WIST_FINAL_EVIDENCE_BOUNDARY_TIERS.csv`: final A/B/C evidence-tier table.
- `WIST_DIRECTOR_FINAL_DECISION_MEMO.md`: director-level final decision memo.

### `evidence_foundation/`
Use these as the facility-level public evidence foundation and source-verification records:

- `WIST_16_FACILITY_PUBLIC_EVIDENCE_TABLE.csv`
- `WIST_16_FACILITY_EVIDENCE_BOUNDARY_SUMMARY.csv`
- `WIST_16_FACILITY_SOURCE_VERIFICATION_MEMO.md`
- `WIST_16_FACILITY_EVIDENCE_GAP_LOG.csv`
- `WIST_SOURCE_VERIFICATION_AUDIT_TABLE_CORRECTED.csv`
- `WIST_SOURCE_VERIFICATION_AUDIT_MEMO_CORRECTED.md`
- supplemental targeted evidence files prefixed with `supplemental_`.

### `final_reconciliation/`
Use these as the final conflict-resolution files for D03, D05, D07, D11, D14, and D16:

- `WIST_TARGETED_SUPPLEMENTAL_RECONCILIATION_TABLE_FINAL.csv`
- `WIST_TARGETED_SUPPLEMENTAL_RECONCILIATION_MEMO_FINAL.md`

### `audit_appendix/`
Use these only for reproducibility and internal review:

- `WIST_EVIDENCE_TO_SCORE_LEDGER_FINAL.csv`
- `WIST_NUMERIC_DERIVATION_APPENDIX.csv`
- `WIST_FINAL_QA_LEDGER.csv`
- `WIST_PRIOR_PACKAGE_INDEX_SUPERSEDED_REFERENCE.md`

## Required paper caveat

Facility-level evidence supports three evidence tiers across the fixed D01–D16 WIST origins: direct station-support relevance for D01, D06, and D09; indirect logistics or operations-support relevance for D02, D03, D04, D05, D07, D08, D10, D13, and D15; and generic service-center or work-location evidence for D11, D12, D14, and D16. None of the facilities is interpreted as a publicly verified high-voltage/substation repair crew base, observed crew roster, dispatch assignment, or measured depot-level repair capacity.

## Prohibited interpretations

Do not interpret WIST as observed crew count, yard-level roster, measured depot repair capacity, utility workforce share, restoration responsibility share, emergency dispatch share, or evidence for total crew number.
