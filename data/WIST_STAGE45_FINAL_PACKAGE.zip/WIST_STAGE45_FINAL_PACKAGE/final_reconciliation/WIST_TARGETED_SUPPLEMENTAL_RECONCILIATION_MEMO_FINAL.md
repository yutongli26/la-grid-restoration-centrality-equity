# WIST targeted supplemental evidence reconciliation memo — FINAL

## Scope

This final reconciliation compares only the conflict rows D03, D05, D07, D11, D14, and D16 between `Facility Evidence Extraction Task.pdf` and `WIST_TARGETED_SUPPLEMENTAL_EVIDENCE_PACKAGE.zip`. The PDF-side source/category/quote fields were explicitly checked against the PDF-derived extraction record rather than replaced with older appendix lineage. The supplemental side was checked against the targeted supplemental evidence package.

No WIST weights, ratios, normalized weights, crew numbers, coordinates, origin-list membership, yard status, code, or damaged-substation candidate sets were changed.

The governing boundary is evidentiary category only. Garage, service-center, warehouse, site-scale, AOR, paving, or service-planning evidence may support caveated origin-proxy use, but it is not observed depot-level repair capacity. No source in this reconciliation proves an observed high-voltage/substation repair crew base, facility-level crew roster, dispatch assignment, or measured repair capacity.

## Category rules applied

Category A is reserved for direct high-voltage, substation, station-equipment, T&D, or station-material support evidence. Category B is used for facility-specific logistics or operations-support evidence such as garage, warehouse, loading dock, service yard, fleet, prefab, vehicle maintenance, materials, equipment storage, or field logistics. Category C is used for generic service-center, work-location, service-planning, site-scale, or local-operations evidence only.

Service-center status, square footage, paving/site-work, geography, and utility ownership were not treated as crew-capacity evidence.

## Row-by-row reconciliation

### D03 — LADWP Boylston Facility

PDF side: the extraction record treated the Boylston / Station 11 evidence as potentially direct, but the usable facility-specific source is the official LADWP Boylston Facility filming-location page. It identifies the facility and labels parking garage, office building and garage, warehouse loading dock, Station 11 entrance, and Station 11.

Supplemental side: the targeted supplemental package uses the same official LADWP facility page and classifies the evidence as indirect logistics / operations support.

Final category: **B. Indirect logistics / operations support evidence.** The source is real, official, and facility-specific. However, under the special D03 rule, Station 11 or historical control/dispatch context cannot by itself support Category A unless a source proves current facility-level station-equipment or substation support. No such current proof was identified.

### D05 — LADWP Central Service Center

PDF side: the Facility Evidence Extraction source is `Central Service Center - Admin & WH`, which identifies LADWP ownership, office property type, 131,300 square feet, and the Admin & WH label.

Supplemental side: the targeted supplemental package did not identify a stronger D05-specific source.

Final category: **B. Indirect logistics / operations support evidence, with secondary Category C work-location/site-scale context.** The Admin & WH source supports warehouse/work-location/site-scale context. It does not support Category A or direct HV/substation/station-equipment relevance.

### D07 — SCE Dominguez Hills Service Center

PDF side: the extraction record contains two relevant source tracks. The GRC facility-list source alone supports Category C because it confirms a service center, 3 buildings, and 92,116 exterior gross square feet. The retained DIR/DOSH pressure-vessel registration source identifies SCE CRE - Dominguez Hills Service C at 1924 E Cashdan St, with `garage oil room` and `outside prefab` locations; if that DIR/DOSH row is retained, it supports Category B.

Supplemental side: the targeted supplemental package did not add a stronger D07-specific source and treated D07 as caveated.

Final category: **B. Indirect logistics / operations support evidence.** The DIR/DOSH source is a public-agency, facility-specific source supporting garage/prefab logistics context. This is not direct HV/substation support and not observed repair crew-base proof.

### D11 — SCE Montebello Service Center

PDF side: the SCE GRC facility-list source identifies Montebello Service Center under SERVICE CENTER, with year built 1975, 1 location, 3 buildings, and 40,321 exterior gross square feet. This supports Category C only.

Supplemental side: the job-posting mirror references an AOR that includes Montebello Service Center, Whittier Service Center, Mesa Substation, Center Substation, Irwindale Warehouse and Garage, Randolph Contractor Store, and associated unmanned substations; it states that the office is located at SCE Montebello Service Center.

Final category: **C. Generic service-center / work-location evidence only.** The job-posting mirror is weaker and AOR-level. It does not prove that Montebello itself has garage, service bays, fleet, materials, T&D trucks, HV/substation support, or repair crews.

### D14 — SCE Covina / San Dimas Service Center

PDF side: the SCE GRC facility-list source identifies Covina Service Center under SERVICE CENTER, with year built 1980, 1 location, 3 buildings, and 65,142 exterior gross square feet. This supports Category C only.

Supplemental side: the CIWQS record lists Covina Service Center Paving among SCE facility/project records.

Final category: **C. Generic service-center / work-location evidence only.** Paving/site-work and service-center square footage do not prove logistics, materials, garage, fuel island, laydown, T&D support, HV/substation support, or repair crews.

### D16 — SCE Long Beach Service Center

PDF side: the SCE GRC facility-list source identifies Long Beach Service Center under SERVICE CENTER, with year built 1968, 1 location, 2 buildings, and 50,086 exterior gross square feet. This supports Category C only.

Supplemental side: the SCE Electrical Service Requirements service-planning location table lists Long Beach as an SCE service center/location.

Final category: **C. Generic service-center / work-location evidence only.** The sources confirm service-center identity and service-planning/site-scale context but not garage, wash bay, hazmat storage, war-room dispatch, fleet, material laydown, T&D/substation support, or repair crew evidence.

## Final summary

1. Rows finally Category A: none
2. Rows finally Category B: D03, D05, D07
3. Rows finally Category C: D11, D14, D16
4. Rows unresolved because source could not be verified: none
5. Rows publicly proven as observed HV/substation repair crew bases: none
6. Does this require WIST weight changes: no
7. Main paper caveat: The reconciled categories support only caveated WIST origin-proxy evidence boundaries. They do not prove observed crew bases, facility-level rosters, measured repair capacity, utility staffing shares, or dispatch shares.
